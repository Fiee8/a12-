//
//  payload.h
//  rootlessJB
//
//  Created by Jake James on 8/29/18.
//  Copyright © 2018 Jake James. All rights reserved.
//

#ifndef payload_h
#define payload_h

#include <stdio.h>

char* prepare_payload(void);

#endif /* payload_h */
