//
//  lzssdec.hpp
//  KernelSymbolFinder
//
//  Created by Jake James on 8/21/18.
//  Copyright © 2018 Jake James. All rights reserved.
//

#ifndef lzssdec_hpp
#define lzssdec_hpp

#include <stdio.h>

int lzssdec(int argc,char**argv);

#endif /* lzssdec_hpp */
